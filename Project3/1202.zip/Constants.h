#pragma once

#define WINDOW_X 200
#define WINDOW_Y 200

#define WINDOW_WIDTH 1200	// window's width
#define WINDOW_HEIGHT 800		// window's height

#define boundaryX (WINDOW_WIDTH)/2
#define boundaryY (WINDOW_HEIGHT)/2